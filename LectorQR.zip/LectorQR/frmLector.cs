﻿using AForge.Video;
using AForge.Video.DirectShow;
using System;
using System.Drawing;
using System.Windows.Forms;
using ZXing;

namespace LectorQR
{
    public partial class frmLector : Form
    {
        private FilterInfoCollection videoDevices;
        private VideoCaptureDevice videoSource;


        private BarcodeReader reader = new BarcodeReader();
        private Bitmap bitmap;

        public frmLector()
        {
            InitializeComponent();
            videoDevices = new FilterInfoCollection(FilterCategory.VideoInputDevice);
            videoSource = new VideoCaptureDevice(videoDevices[0].MonikerString); 
            videoSource.NewFrame += new NewFrameEventHandler(VideoSource_NewFrame);
        }

        private void VideoSource_NewFrame(object sender, NewFrameEventArgs eventArgs)
        {
            bitmap = (Bitmap)eventArgs.Frame.Clone();
            var result = reader.Decode(bitmap);

            Image img = (Image)eventArgs.Frame.Clone();
            img.RotateFlip(RotateFlipType.Rotate180FlipY);
            pictureBox1.Image = img;

            
            
            if (result != null)
            {
                Invoke(new MethodInvoker(delegate ()
                {
                    txtId.Text = result.Text;  
                    videoSource.SignalToStop();   
                }));
            }
        }

        //Esta funcion verifica que la camara este apagada al cerrar la aplicacion
        private void frmLector_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (videoSource != null && videoSource.IsRunning)
                turnOff();
        }

        //Este boton simplemente prende o apaga la camara
        private void btnTomar_Click(object sender, EventArgs e)
        {
            if (!videoSource.IsRunning)
            {
                //La utilidad de estos if es verificar si el textbox y la imagen tienen algun valor
                //En caso de ya tener un valor, los borra para tomar uno nuevo
                if (videoSource != null)
                    pictureBox1.Image = null;
                if (txtId.Text != null)
                    txtId.Text = null;

                //El MessageBox no es necesario, solo se usa como bandera de que prende o no la camara
                MessageBox.Show("Acabas de prender la camara");
                videoSource.Start();
            }
            else
            {
                //El MessageBox no es necesario, solo se usa como bandera de que prende o no la camara
                MessageBox.Show("Acabas de apagar la camara");
                turnOff();
            }
        }

        //Esta funcion apaga la camara, quita la foto ya puesta y borra el textbox
        private void turnOff()
        {
            pictureBox1.Image = null;
            txtId.Text = null;
            videoSource.SignalToStop();

        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            //Aqui deberia volver al formulario anterior
        }
    }
}
